/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author siswa-RPL3-11
 */
public class dbkoneksi {
    private static Connection koneksi;
    public static Connection getKoneksi(){
        String host ="jdbc:mysql://localhost/dbstokbrg",
                user ="root",
                pass ="";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            koneksi = DriverManager.getConnection(host, user, pass);
        } catch (Exception e){
            System.err.println("koneksi gagal: "+e.getMessage());
        }
        return koneksi;
    }
    public static void main(String[] args){
        
    }
}
